const searchInput = document.getElementById("searchInput");
const categoryButtons = [...document.querySelectorAll(".category")];
const productCards = [...document.querySelectorAll(".product-card")];
const emptyState = document.getElementById("emptyState");
let selectedCategory = "Semua";
const cart = new Map();
const rupiah = value => new Intl.NumberFormat("id-ID", {style:"currency", currency:"IDR", maximumFractionDigits:0}).format(value);

function filterProducts() {
  const query = (searchInput.value || "").toLowerCase().trim();
  let visible = 0;
  productCards.forEach(card => {
    const matchesName = card.dataset.name.toLowerCase().includes(query);
    const matchesCategory = selectedCategory === "Semua" || card.dataset.category === selectedCategory;
    card.hidden = !(matchesName && matchesCategory);
    if (!card.hidden) visible++;
  });
  emptyState.hidden = visible !== 0;
}
searchInput.addEventListener("input", filterProducts);
categoryButtons.forEach(button => button.addEventListener("click", () => {
  selectedCategory = button.dataset.category;
  categoryButtons.forEach(item => item.classList.toggle("active", item === button));
  filterProducts();
}));

const toast = document.getElementById("toast");
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
document.querySelectorAll(".add-button").forEach(button => button.addEventListener("click", () => {
  const name = button.dataset.name;
  const price = Number(button.dataset.price);
  const item = cart.get(name) || {name, price, quantity:0};
  item.quantity++;
  cart.set(name, item);
  renderCart();
  showToast(name + " ditambahkan ke keranjang");
}));
document.querySelectorAll(".heart-button").forEach(button => button.addEventListener("click", () => {
  button.classList.toggle("liked");
  button.textContent = button.classList.contains("liked") ? "♥" : "♡";
  showToast(button.classList.contains("liked") ? "Ditambahkan ke favorit" : "Dihapus dari favorit");
}));

const cartPanel = document.getElementById("cartPanel");
const overlay = document.getElementById("overlay");
function openCart() { cartPanel.classList.add("open"); overlay.classList.add("open"); cartPanel.setAttribute("aria-hidden","false"); }
function closeCart() { cartPanel.classList.remove("open"); overlay.classList.remove("open"); cartPanel.setAttribute("aria-hidden","true"); }
document.getElementById("cartButton").addEventListener("click", openCart);
document.getElementById("closeCart").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);
document.addEventListener("keydown", event => { if (event.key === "Escape") closeCart(); });

function renderCart() {
  const itemsContainer = document.getElementById("cartItems");
  const items = [...cart.values()];
  const count = items.reduce((sum,item) => sum + item.quantity, 0);
  const total = items.reduce((sum,item) => sum + item.price * item.quantity, 0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("cartTotal").textContent = rupiah(total);
  if (!items.length) {
    itemsContainer.innerHTML = '<p class="cart-empty">Keranjangmu masih kosong.</p>';
    return;
  }
  itemsContainer.innerHTML = items.map(item => `
    <div class="cart-line">
      <div><strong>${escapeHtml(item.name)}</strong><small>${rupiah(item.price)} / produk</small></div>
      <div class="quantity-controls">
        <button data-action="minus" data-name="${escapeHtml(item.name)}" aria-label="Kurangi jumlah">−</button>
        <span>${item.quantity}</span>
        <button data-action="plus" data-name="${escapeHtml(item.name)}" aria-label="Tambah jumlah">+</button>
      </div>
    </div>`).join("");
  itemsContainer.querySelectorAll("button").forEach(button => button.addEventListener("click", () => {
    const item = cart.get(button.dataset.name);
    if (!item) return;
    if (button.dataset.action === "plus") item.quantity++;
    else item.quantity--;
    if (item.quantity <= 0) cart.delete(item.name);
    renderCart();
  }));
}
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[char]));
}
document.getElementById("checkoutButton").addEventListener("click", () => {
  if (cart.size === 0) { showToast("Tambahkan produk terlebih dahulu"); return; }
  showToast("Keranjang siap. Checkout belum terhubung ke backend.");
});
renderCart();
