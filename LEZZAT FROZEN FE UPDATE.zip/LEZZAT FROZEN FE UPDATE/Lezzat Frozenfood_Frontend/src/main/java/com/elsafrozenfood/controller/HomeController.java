package com.elsafrozenfood.controller;

import com.elsafrozenfood.product.ProductRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    private final ProductRepository products;
    public HomeController(ProductRepository products) { this.products = products; }

    @GetMapping({"/", "/home"})
    public String home(Model model) {
        model.addAttribute("storeName", "LEZZAT Frozen Food");
        model.addAttribute("products", products.findAll(Sort.by("name").ascending()));
        return "index";
    }
}
