package com.elsafrozenfood.order;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "customer_orders")
public class CustomerOrder {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, length=160) private String customerEmail;
    @Column(nullable=false, length=80) private String customerName;
    @Column(nullable=false) private Long productId;
    @Column(nullable=false, length=120) private String productName;
    @Column(nullable=false) private Integer quantity;
    @Column(nullable=false) private Integer unitPrice;
    @Column(nullable=false) private Integer totalPrice;
    @Column(nullable=false, length=24) private String orderStatus = "MENUNGGU_PEMBAYARAN";
    @Column(nullable=false, length=24) private String paymentStatus = "BELUM_DIBAYAR";
    @Column(length=500) private String note;
    @Column(nullable=false, updatable=false) private LocalDateTime createdAt = LocalDateTime.now();

    protected CustomerOrder() {}
    public CustomerOrder(String customerEmail, String customerName, Long productId, String productName, Integer quantity, Integer unitPrice, String note) {
        this.customerEmail=customerEmail; this.customerName=customerName; this.productId=productId; this.productName=productName;
        this.quantity=quantity; this.unitPrice=unitPrice; this.totalPrice=quantity*unitPrice; this.note=note;
    }
    public void update(Integer quantity, String note) { this.quantity=quantity; this.totalPrice=quantity*unitPrice; this.note=note; }
    public Long getId(){return id;} public String getCustomerEmail(){return customerEmail;} public String getCustomerName(){return customerName;}
    public Long getProductId(){return productId;} public String getProductName(){return productName;} public Integer getQuantity(){return quantity;}
    public Integer getUnitPrice(){return unitPrice;} public Integer getTotalPrice(){return totalPrice;} public String getOrderStatus(){return orderStatus;}
    public String getPaymentStatus(){return paymentStatus;} public String getNote(){return note;} public LocalDateTime getCreatedAt(){return createdAt;}
    public void setPaymentStatus(String paymentStatus){this.paymentStatus=paymentStatus;}
    public void setOrderStatus(String orderStatus){this.orderStatus=orderStatus;}
}
