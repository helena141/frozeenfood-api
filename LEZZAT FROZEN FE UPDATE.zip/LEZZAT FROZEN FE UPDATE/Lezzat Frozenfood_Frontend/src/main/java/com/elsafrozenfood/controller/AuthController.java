package com.elsafrozenfood.controller;

import com.elsafrozenfood.service.RegistrationService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {
    private final RegistrationService registrationService;
    public AuthController(RegistrationService registrationService) { this.registrationService = registrationService; }

    @GetMapping("/login")
    public String login() { return "auth/login"; }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("registration", new RegistrationForm());
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registration") RegistrationForm form,
                           BindingResult result, Model model) {
        if (!"B2C".equals(form.getCustomerType()) && !"B2B".equals(form.getCustomerType())) {
            result.rejectValue("customerType", "customerType.invalid", "Jenis akun tidak valid.");
        }
        if (!form.getPassword().equals(form.getConfirmPassword())) {
            result.rejectValue("confirmPassword", "password.mismatch", "Konfirmasi kata sandi belum sama.");
        }
        if (result.hasErrors()) return "auth/register";
        try {
            registrationService.register(form.getFullName(), form.getEmail(), form.getPassword(), form.getCustomerType());
            return "redirect:/login?registered";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("registrationError", ex.getMessage());
            return "auth/register";
        }
    }

    public static class RegistrationForm {
        @NotBlank(message = "Nama lengkap wajib diisi.") @Size(max = 80, message = "Nama maksimal 80 karakter.")
        private String fullName;
        @NotBlank(message = "Email wajib diisi.") @Email(message = "Format email tidak valid.") @Size(max = 160)
        private String email;
        @NotBlank(message = "Kata sandi wajib diisi.") @Size(min = 8, max = 72, message = "Kata sandi harus terdiri dari 8–72 karakter.")
        private String password;
        @NotBlank(message = "Konfirmasi kata sandi wajib diisi.") private String confirmPassword;
        private String customerType = "B2C";
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getCustomerType() { return customerType; }
        public void setCustomerType(String customerType) { this.customerType = customerType; }
        public String getConfirmPassword() { return confirmPassword; }
        public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }
    }
}
