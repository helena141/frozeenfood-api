package com.elsafrozenfood.service;

import com.elsafrozenfood.auth.AppUser;
import com.elsafrozenfood.repository.AppUserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegistrationService {
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    public RegistrationService(AppUserRepository users, PasswordEncoder passwordEncoder) {
        this.users = users; this.passwordEncoder = passwordEncoder;
    }
    @Transactional
    public void register(String fullName, String email, String password, String customerType) {
        String normalizedEmail = email.trim().toLowerCase();
        if (users.existsByEmailIgnoreCase(normalizedEmail)) throw new IllegalArgumentException("Email sudah terdaftar. Silakan masuk atau gunakan email lain.");
        String role = "B2B".equalsIgnoreCase(customerType) ? "B2B" : "B2C";
        AppUser user = new AppUser(fullName.trim(), normalizedEmail, passwordEncoder.encode(password));
        user.setRole(role);
        users.save(user);
    }
}
