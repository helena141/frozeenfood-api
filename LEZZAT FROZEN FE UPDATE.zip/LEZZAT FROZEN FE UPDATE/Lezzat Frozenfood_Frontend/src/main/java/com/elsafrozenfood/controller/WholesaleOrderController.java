package com.elsafrozenfood.controller;

import com.elsafrozenfood.auth.AppUser;
import com.elsafrozenfood.product.Product;
import com.elsafrozenfood.product.ProductRepository;
import com.elsafrozenfood.repository.AppUserRepository;
import com.elsafrozenfood.wholesale.WholesaleOrder;
import com.elsafrozenfood.wholesale.WholesaleOrderRepository;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Controller
public class WholesaleOrderController {
    private final WholesaleOrderRepository orders; private final ProductRepository products; private final AppUserRepository users;
    public WholesaleOrderController(WholesaleOrderRepository orders, ProductRepository products, AppUserRepository users) { this.orders=orders; this.products=products; this.users=users; }

    @GetMapping("/wholesale-orders")
    public String myOrders(Authentication auth, Model model) {
        model.addAttribute("orders", orders.findByCustomerEmailIgnoreCaseOrderByCreatedAtDesc(auth.getName()));
        return "wholesale/list";
    }

    @PostMapping("/wholesale-orders/create/{productId}")
    public String create(@PathVariable Long productId, @RequestParam(defaultValue="10") Integer quantity, @RequestParam(required=false) String note, Authentication auth, RedirectAttributes redirect) {
        Product product=products.findById(productId).orElse(null);
        if(product==null){redirect.addFlashAttribute("errorMessage","Produk tidak ditemukan.");return "redirect:/products";}
        if(quantity==null || quantity<1 || quantity>10000){redirect.addFlashAttribute("errorMessage","Jumlah pesanan grosir harus 1–10.000.");return "redirect:/products";}
        if(product.getStock()<quantity){redirect.addFlashAttribute("errorMessage","Stok tidak mencukupi untuk jumlah grosir tersebut.");return "redirect:/products";}
        AppUser user=users.findByEmailIgnoreCase(auth.getName()).orElseThrow();
        product.setStock(product.getStock()-quantity); products.save(product);
        orders.save(new WholesaleOrder(user.getEmail(),user.getFullName(),product.getId(),product.getName(),quantity,product.getPrice(),cleanNote(note)));
        redirect.addFlashAttribute("successMessage","Pesanan grosir berhasil dibuat. Silakan lanjutkan pembayaran demo.");return "redirect:/wholesale-orders";
    }

    @PostMapping("/wholesale-orders/{id}/edit")
    public String edit(@PathVariable Long id,@RequestParam Integer quantity,@RequestParam(required=false) String note,Authentication auth,RedirectAttributes redirect){
        WholesaleOrder order=ownedOrder(id,auth.getName());
        if(order==null)
            {redirect.addFlashAttribute("errorMessage","Pesanan grosir tidak ditemukan.");
        return "redirect:/wholesale-orders";}
        if(!"BELUM_DIBAYAR".equals(order.getPaymentStatus()))
            {redirect.addFlashAttribute("errorMessage","Pesanan yang sudah dibayar tidak dapat diedit.");
        return "redirect:/wholesale-orders";}
        if(quantity==null||quantity<1||quantity>10000)
            {redirect.addFlashAttribute("errorMessage","Jumlah pesanan grosir harus 1–10.000.");
        return "redirect:/wholesale-orders";}
        Product product=products.findById(order.getProductId()).orElse(null);
        if(product==null){redirect.addFlashAttribute("errorMessage","Produk tidak tersedia.");
        return "redirect:/wholesale-orders";}
        int delta=quantity-order.getQuantity(); 
        if(delta>product.getStock()){redirect.addFlashAttribute("errorMessage","Stok tidak mencukupi.");
        return "redirect:/wholesale-orders";}
        product.setStock(product.getStock()-delta);
        products.save(product);
        order.update(quantity,cleanNote(note));
        orders.save(order);
        redirect.addFlashAttribute("successMessage","Pesanan grosir berhasil diperbarui.");
        return "redirect:/wholesale-orders";
    }

    @PostMapping("/wholesale-orders/{id}/delete")
    public String delete(@PathVariable Long id,Authentication auth,RedirectAttributes redirect){
        WholesaleOrder order=ownedOrder(id,auth.getName());
        if(order==null){redirect.addFlashAttribute("errorMessage","Pesanan grosir tidak ditemukan.");
        return "redirect:/wholesale-orders";}
        if(!"BELUM_DIBAYAR".equals(order.getPaymentStatus()))
            {redirect.addFlashAttribute("errorMessage","Pesanan yang sudah dibayar tidak dapat dihapus.");
        return "redirect:/wholesale-orders";}
        products.findById(order.getProductId()).ifPresent(p->{p.setStock(p.getStock()+order.getQuantity());
            products.save(p);});orders.delete(order);
        redirect.addFlashAttribute("successMessage","Pesanan grosir dihapus dan stok dikembalikan.");
        return "redirect:/wholesale-orders";
    }

    @PostMapping("/wholesale-orders/{id}/pay")
    public String pay(@PathVariable Long id,Authentication auth,RedirectAttributes redirect){
        WholesaleOrder order=ownedOrder(id,auth.getName());
        if(order==null){redirect.addFlashAttribute("errorMessage","Pesanan grosir tidak ditemukan.");
        return "redirect:/wholesale-orders";}
        if(!"BELUM_DIBAYAR".equals(order.getPaymentStatus()))
            {redirect.addFlashAttribute("errorMessage","Pesanan ini sudah dibayar.");return "redirect:/wholesale-orders";}
        order.setPaymentStatus("LUNAS_DEMO");
        order.setOrderStatus("DIPROSES");orders.save(order);
        redirect.addFlashAttribute("successMessage","Pembayaran simulasi berhasil; tidak ada transaksi uang sungguhan.");
        return "redirect:/wholesale-orders";
    }

    @GetMapping("/wholesale-orders/{id}/receipt")
    public void ownReceipt(@PathVariable Long id,Authentication auth,HttpServletResponse response)throws IOException{WholesaleOrder order=ownedOrder(id,auth.getName());if(order==null){response.sendError(404);return;}writeReceipt(order,response);}

    @GetMapping("/admin/wholesale-orders")
    public String adminOrders(Model model){model.addAttribute("orders",orders.findAll(Sort.by(Sort.Direction.DESC,"createdAt")));return "admin/wholesale-orders";}
    @GetMapping("/admin/wholesale-orders/{id}/receipt")
    public void adminReceipt(@PathVariable Long id,HttpServletResponse response)throws IOException{WholesaleOrder order=orders.findById(id).orElse(null);if(order==null){response.sendError(404);return;}writeReceipt(order,response);}

    private WholesaleOrder ownedOrder(Long id,String email){return orders.findByIdAndCustomerEmailIgnoreCase(id,email).orElse(null);}
    private String cleanNote(String note){if(note==null)return "";String n=note.trim();return n.length()>500?n.substring(0,500):n;}
    private void writeReceipt(WholesaleOrder o,HttpServletResponse response)throws IOException{
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());response.setContentType("text/html; charset=UTF-8");response.setHeader(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=nota-pesanan-grosir-"+o.getId()+".html");
        String html="<!doctype html><html lang='id'><meta charset='UTF-8'><title>Nota Pesanan Grosir LEZZAT</title><body style='font-family:Arial,sans-serif;max-width:760px;margin:40px auto;color:#33281f'><h1>LEZZAT FROZEN FOOD</h1><h2>Nota Pesanan Grosir #"+o.getId()+"</h2><hr><p><b>Pelanggan B2B:</b> "+escape(o.getCustomerName())+"</p><p><b>Email:</b> "+escape(o.getCustomerEmail())+"</p><p><b>Tanggal:</b> "+o.getCreatedAt()+"</p><table style='width:100%;border-collapse:collapse' border='1' cellpadding='10'><tr><th>Produk</th><th>Jumlah grosir</th><th>Harga satuan</th><th>Total</th></tr><tr><td>"+escape(o.getProductName())+"</td><td>"+o.getQuantity()+"</td><td>Rp "+o.getUnitPrice()+"</td><td>Rp "+o.getTotalPrice()+"</td></tr></table><p><b>Status pembayaran:</b> "+escape(o.getPaymentStatus())+"</p><p><b>Status pesanan:</b> "+escape(o.getOrderStatus())+"</p><p><b>Catatan:</b> "+escape(o.getNote()==null?"":o.getNote())+"</p><p>Nota pesanan grosir LEZZAT Frozen Food.</p></body></html>";
        response.getOutputStream().write(html.getBytes(StandardCharsets.UTF_8));
    }
    private String escape(String v){return v==null?"":v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
}
