package com.elsafrozenfood.controller;

import com.elsafrozenfood.auth.AppUser;
import com.elsafrozenfood.repository.AppUserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CustomerController {
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;

    public CustomerController(AppUserRepository users, PasswordEncoder passwordEncoder) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/account")
    public String account(Authentication authentication, Model model) {
        AppUser user = currentUser(authentication);
        if (user == null) return "redirect:/login";
        model.addAttribute("customer", user);
        return "account/profile";
    }

    @PostMapping("/account/edit")
    public String editAccount(Authentication authentication, @RequestParam String fullName,
            @RequestParam String email, @RequestParam(required = false) String password,
            RedirectAttributes redirect) {
        AppUser user = currentUser(authentication);
        if (user == null) return "redirect:/login";
        String normalizedEmail = email.trim().toLowerCase();
        if (fullName.trim().isEmpty() || fullName.trim().length() > 80 ||
                normalizedEmail.isEmpty() || normalizedEmail.length() > 160 || !normalizedEmail.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            redirect.addFlashAttribute("errorMessage", "Nama atau format email tidak valid.");
            return "redirect:/account";
        }
        if (!user.getEmail().equalsIgnoreCase(normalizedEmail) && users.existsByEmailIgnoreCase(normalizedEmail)) {
            redirect.addFlashAttribute("errorMessage", "Email tersebut sudah digunakan akun lain.");
            return "redirect:/account";
        }
        user.setFullName(fullName.trim());
        user.setEmail(normalizedEmail);
        if (password != null && !password.isBlank()) {
            if (password.length() < 8 || password.length() > 72) {
                redirect.addFlashAttribute("errorMessage", "Kata sandi baru harus terdiri dari 8–72 karakter.");
                return "redirect:/account";
            }
            user.setPassword(passwordEncoder.encode(password));
        }
        users.save(user);
        redirect.addFlashAttribute("successMessage", "Akun berhasil diperbarui.");
        return "redirect:/account";
    }

    @PostMapping("/account/delete")
    public String deleteOwnAccount(Authentication authentication, RedirectAttributes redirect) {
        AppUser user = currentUser(authentication);
        if (user == null) return "redirect:/login";
        if ("ADMIN".equals(user.getRole())) {
            redirect.addFlashAttribute("errorMessage", "Akun admin tidak dapat dihapus dari menu akun sendiri.");
            return "redirect:/account";
        }
        users.delete(user);
        return "redirect:/login?accountDeleted";
    }

    @GetMapping("/admin/customers")
    public String customerList(Model model) {
        model.addAttribute("customers", users.findAll().stream().filter(user -> !"ADMIN".equals(user.getRole())).toList());
        return "admin/customers";
    }

    @GetMapping("/admin/customers/{id}")
    public String customerDetail(@PathVariable Long id, Model model, RedirectAttributes redirect) {
        var customer = users.findById(id);
        if (customer.isEmpty()) {
            redirect.addFlashAttribute("errorMessage", "Akun pelanggan tidak ditemukan.");
            return "redirect:/admin/customers";
        }
        model.addAttribute("customer", customer.get());
        return "admin/customer-detail";
    }

    @PostMapping("/admin/customers/{id}/delete")
    public String deleteCustomer(@PathVariable Long id, RedirectAttributes redirect) {
        var customer = users.findById(id);
        if (customer.isEmpty()) {
            redirect.addFlashAttribute("errorMessage", "Akun pelanggan tidak ditemukan.");
        } else if ("ADMIN".equals(customer.get().getRole())) {
            redirect.addFlashAttribute("errorMessage", "Akun admin tidak dapat dihapus dari daftar pelanggan.");
        } else {
            users.delete(customer.get());
            redirect.addFlashAttribute("successMessage", "Akun pelanggan berhasil dihapus.");
        }
        return "redirect:/admin/customers";
    }

    private AppUser currentUser(Authentication authentication) {
        if (authentication == null) return null;
        return users.findByEmailIgnoreCase(authentication.getName()).orElse(null);
    }
}
