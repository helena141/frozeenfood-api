package com.elsafrozenfood.config;

import com.elsafrozenfood.auth.AppUser;
import com.elsafrozenfood.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AdminAccountInitializer {
    @Bean
    CommandLineRunner createConfiguredAdmin(AppUserRepository users, PasswordEncoder encoder,
            @Value("${app.admin.email:}") String adminEmail,
            @Value("${app.admin.password:}") String adminPassword,
            @Value("${app.admin.name:Administrator LEZZAT}") String adminName) {
        return args -> {
            // Admin hanya dibuat jika kredensial diberikan lewat environment/config.
            if (adminEmail.isBlank() || adminPassword.isBlank()) return;
            String email = adminEmail.trim().toLowerCase();
            if (users.existsByEmailIgnoreCase(email)) return;
            if (adminPassword.length() < 12) {
                throw new IllegalStateException("APP_ADMIN_PASSWORD harus minimal 12 karakter.");
            }
            AppUser admin = new AppUser(adminName, email, encoder.encode(adminPassword));
            admin.setRole("ADMIN");
            users.save(admin);
        };
    }
}
