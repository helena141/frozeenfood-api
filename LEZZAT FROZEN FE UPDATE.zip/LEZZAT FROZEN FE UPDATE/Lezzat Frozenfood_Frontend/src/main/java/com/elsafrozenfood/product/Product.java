package com.elsafrozenfood.product;

import jakarta.persistence.*;

@Entity
@Table(name = "products", uniqueConstraints = @UniqueConstraint(name = "uk_products_name", columnNames = "name"))
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 120, unique = true) private String name;
    @Column(nullable = false, length = 80) private String category;
    @Column(nullable = false) private Integer price;
    @Column(nullable = false) private Integer stock = 0;
    @Column(nullable = false, length = 12) private String emoji = "🍗";
    @Column(nullable = false, length = 255) private String description;
    @Column(nullable = false, length = 30) private String colorClass = "product-gold";

    protected Product() {}
    public Product(String name, String category, Integer price, Integer stock, String emoji, String description, String colorClass) {
        this.name = name; this.category = category; this.price = price; this.stock = stock;
        this.emoji = emoji; this.description = description; this.colorClass = colorClass;
    }
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public Integer getPrice() { return price; }
    public Integer getStock() { return stock; }
    public String getEmoji() { return emoji; }
    public String getDescription() { return description; }
    public String getColorClass() { return colorClass; }
    public void setName(String name) { this.name = name; }
    public void setCategory(String category) { this.category = category; }
    public void setPrice(Integer price) { this.price = price; }
    public void setStock(Integer stock) { this.stock = stock; }
    public void setEmoji(String emoji) { this.emoji = emoji; }
    public void setDescription(String description) { this.description = description; }
    public void setColorClass(String colorClass) { this.colorClass = colorClass; }
}
