package com.elsafrozenfood.auth;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "app_users", uniqueConstraints = @UniqueConstraint(name = "uk_app_users_email", columnNames = "email"))
public class AppUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 80) private String fullName;
    @Column(nullable = false, length = 160, unique = true) private String email;
    @Column(nullable = false, length = 100) private String password;
    @Column(nullable = false, length = 30) private String role = "B2C";
    @Column(nullable = false, updatable = false) private LocalDateTime createdAt = LocalDateTime.now();

    protected AppUser() {}
    public AppUser(String fullName, String email, String password) {
        this.fullName = fullName; this.email = email; this.password = password; this.role = "B2C";
    }
    public Long getId() { return id; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(String role) { this.role = role; }
}
