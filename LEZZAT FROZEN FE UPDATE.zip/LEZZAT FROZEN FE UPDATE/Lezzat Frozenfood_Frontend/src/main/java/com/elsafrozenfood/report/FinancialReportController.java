package com.elsafrozenfood.report;

import com.elsafrozenfood.order.CustomerOrder;
import com.elsafrozenfood.order.CustomerOrderRepository;
import com.elsafrozenfood.wholesale.WholesaleOrder;
import com.elsafrozenfood.wholesale.WholesaleOrderRepository;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.function.Predicate;

@Controller
public class FinancialReportController {
    private static final String PAID_DEMO = "LUNAS_DEMO";

    private final CustomerOrderRepository customerOrders;
    private final WholesaleOrderRepository wholesaleOrders;

    public FinancialReportController(CustomerOrderRepository customerOrders,
                                     WholesaleOrderRepository wholesaleOrders) {
        this.customerOrders = customerOrders;
        this.wholesaleOrders = wholesaleOrders;
    }

    @GetMapping("/admin/reports/sales")
    public String salesReport(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            Model model) {
        DateRange range = normalizeRange(from, to);
        List<CustomerOrder> b2c = customerOrders.findAll(Sort.by(Sort.Direction.DESC, "createdAt"))
                .stream().filter(o -> range.includes(o.getCreatedAt())).toList();
        List<WholesaleOrder> b2b = wholesaleOrders.findAll(Sort.by(Sort.Direction.DESC, "createdAt"))
                .stream().filter(o -> range.includes(o.getCreatedAt())).toList();

        long orderCount = b2c.size() + b2b.size();
        long itemCount = b2c.stream().mapToLong(CustomerOrder::getQuantity).sum()
                + b2b.stream().mapToLong(WholesaleOrder::getQuantity).sum();
        long salesValue = b2c.stream().mapToLong(CustomerOrder::getTotalPrice).sum()
                + b2b.stream().mapToLong(WholesaleOrder::getTotalPrice).sum();

        addRange(model, range);
        model.addAttribute("b2cOrders", b2c);
        model.addAttribute("b2bOrders", b2b);
        model.addAttribute("orderCount", orderCount);
        model.addAttribute("itemCount", itemCount);
        model.addAttribute("salesValue", salesValue);
        model.addAttribute("b2cSales", b2c.stream().mapToLong(CustomerOrder::getTotalPrice).sum());
        model.addAttribute("b2bSales", b2b.stream().mapToLong(WholesaleOrder::getTotalPrice).sum());
        return "admin/reports/sales";
    }

    @GetMapping("/admin/reports/finance")
    public String financeReport(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            Model model) {
        DateRange range = normalizeRange(from, to);
        List<CustomerOrder> allB2c = customerOrders.findAll(Sort.by(Sort.Direction.DESC, "createdAt"))
                .stream().filter(o -> range.includes(o.getCreatedAt())).toList();
        List<WholesaleOrder> allB2b = wholesaleOrders.findAll(Sort.by(Sort.Direction.DESC, "createdAt"))
                .stream().filter(o -> range.includes(o.getCreatedAt())).toList();

        List<CustomerOrder> paidB2c = allB2c.stream().filter(o -> PAID_DEMO.equals(o.getPaymentStatus())).toList();
        List<WholesaleOrder> paidB2b = allB2b.stream().filter(o -> PAID_DEMO.equals(o.getPaymentStatus())).toList();
        List<CustomerOrder> unpaidB2c = allB2c.stream().filter(o -> !PAID_DEMO.equals(o.getPaymentStatus())).toList();
        List<WholesaleOrder> unpaidB2b = allB2b.stream().filter(o -> !PAID_DEMO.equals(o.getPaymentStatus())).toList();

        long paidValue = paidB2c.stream().mapToLong(CustomerOrder::getTotalPrice).sum()
                + paidB2b.stream().mapToLong(WholesaleOrder::getTotalPrice).sum();
        long unpaidValue = unpaidB2c.stream().mapToLong(CustomerOrder::getTotalPrice).sum()
                + unpaidB2b.stream().mapToLong(WholesaleOrder::getTotalPrice).sum();
        long paidCount = paidB2c.size() + paidB2b.size();
        long unpaidCount = unpaidB2c.size() + unpaidB2b.size();

        addRange(model, range);
        model.addAttribute("paidB2cOrders", paidB2c);
        model.addAttribute("paidB2bOrders", paidB2b);
        model.addAttribute("unpaidB2cOrders", unpaidB2c);
        model.addAttribute("unpaidB2bOrders", unpaidB2b);
        model.addAttribute("paidValue", paidValue);
        model.addAttribute("unpaidValue", unpaidValue);
        model.addAttribute("paidCount", paidCount);
        model.addAttribute("unpaidCount", unpaidCount);
        model.addAttribute("paidB2cValue", paidB2c.stream().mapToLong(CustomerOrder::getTotalPrice).sum());
        model.addAttribute("paidB2bValue", paidB2b.stream().mapToLong(WholesaleOrder::getTotalPrice).sum());
        return "admin/reports/finance";
    }

    private DateRange normalizeRange(LocalDate from, LocalDate to) {
        LocalDate actualFrom = from;
        LocalDate actualTo = to;
        if (actualFrom != null && actualTo != null && actualFrom.isAfter(actualTo)) {
            LocalDate temp = actualFrom;
            actualFrom = actualTo;
            actualTo = temp;
        }
        return new DateRange(actualFrom, actualTo);
    }

    private void addRange(Model model, DateRange range) {
        model.addAttribute("fromDate", range.from() == null ? "" : range.from().toString());
        model.addAttribute("toDate", range.to() == null ? "" : range.to().toString());
    }

    private record DateRange(LocalDate from, LocalDate to) {
        boolean includes(LocalDateTime dateTime) {
            if (dateTime == null) return false;
            LocalDate date = dateTime.toLocalDate();
            return (from == null || !date.isBefore(from)) && (to == null || !date.isAfter(to));
        }
    }
}
