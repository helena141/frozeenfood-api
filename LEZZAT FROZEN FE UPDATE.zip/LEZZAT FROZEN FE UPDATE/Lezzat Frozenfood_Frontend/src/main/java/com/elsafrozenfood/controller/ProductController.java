package com.elsafrozenfood.controller;

import com.elsafrozenfood.product.Product;
import com.elsafrozenfood.product.ProductRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ProductController {
    private final ProductRepository products;
    public ProductController(ProductRepository products) { this.products = products; }

    // Katalog yang dapat dilihat dan dicari pelanggan.
    @GetMapping("/products")
    public String catalog(@RequestParam(name = "q", required = false, defaultValue = "") String q, Model model) {
        model.addAttribute("products", q.isBlank() ? products.findAll(Sort.by("name").ascending()) :
                products.findByNameContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrderByNameAsc(q.trim(), q.trim()));
        model.addAttribute("q", q);
        return "products/catalog";
    }

    // Semua operasi pengelolaan produk dibatasi untuk ADMIN oleh SecurityConfig.
    @GetMapping("/admin/products")
    public String manageProducts(Model model) {
        model.addAttribute("products", products.findAll(Sort.by("name").ascending()));
        model.addAttribute("productForm", new ProductForm());
        return "admin/products";
    }

    @PostMapping("/admin/products")
    public String addProduct(@Valid @ModelAttribute("productForm") ProductForm form, BindingResult result,
                             Model model, RedirectAttributes redirect) {
        if (products.existsByNameIgnoreCase(form.getName() == null ? "" : form.getName().trim())) {
            result.rejectValue("name", "duplicate", "Nama produk sudah digunakan.");
        }
        if (result.hasErrors()) {
            model.addAttribute("products", products.findAll(Sort.by("name").ascending()));
            return "admin/products";
        }
        products.save(new Product(form.getName().trim(), form.getCategory().trim(), form.getPrice(), form.getStock(),
                normalizeEmoji(form.getEmoji()), form.getDescription().trim(), normalizeColor(form.getColorClass())));
        redirect.addFlashAttribute("successMessage", "Produk berhasil ditambahkan.");
        return "redirect:/admin/products";
    }

    @PostMapping("/admin/products/{id}/stock")
    public String updateStock(@PathVariable Long id, @RequestParam @Min(0) Integer stock, RedirectAttributes redirect) {
        Product product = products.findById(id).orElse(null);
        if (product == null) {
            redirect.addFlashAttribute("errorMessage", "Produk tidak ditemukan.");
        } else if (stock == null || stock < 0) {
            redirect.addFlashAttribute("errorMessage", "Stok harus berupa angka nol atau lebih.");
        } else {
            product.setStock(stock);
            products.save(product);
            redirect.addFlashAttribute("successMessage", "Stok " + product.getName() + " berhasil diperbarui.");
        }
        return "redirect:/admin/products";
    }

    @PostMapping("/admin/products/{id}/delete")
    public String deleteProduct(@PathVariable Long id, RedirectAttributes redirect) {
        if (!products.existsById(id)) redirect.addFlashAttribute("errorMessage", "Produk tidak ditemukan.");
        else {
            products.deleteById(id);
            redirect.addFlashAttribute("successMessage", "Produk berhasil dihapus.");
        }
        return "redirect:/admin/products";
    }

    private String normalizeEmoji(String emoji) { return emoji == null || emoji.isBlank() ? "🍗" : emoji.trim(); }
    private String normalizeColor(String color) {
        return switch (color == null ? "" : color) {
            case "product-pink", "product-green", "product-blue", "product-lilac", "product-peach", "product-cyan", "product-cream" -> color;
            default -> "product-gold";
        };
    }

    public static class ProductForm {
        @NotBlank @Size(max = 120) private String name;
        @NotBlank @Size(max = 80) private String category;
        @NotNull @Min(1) private Integer price;
        @NotNull @Min(0) private Integer stock;
        @Size(max = 12) private String emoji = "🍗";
        @NotBlank @Size(max = 255) private String description;
        private String colorClass = "product-gold";
        public String getName() { return name; } public void setName(String name) { this.name = name; }
        public String getCategory() { return category; } public void setCategory(String category) { this.category = category; }
        public Integer getPrice() { return price; } public void setPrice(Integer price) { this.price = price; }
        public Integer getStock() { return stock; } public void setStock(Integer stock) { this.stock = stock; }
        public String getEmoji() { return emoji; } public void setEmoji(String emoji) { this.emoji = emoji; }
        public String getDescription() { return description; } public void setDescription(String description) { this.description = description; }
        public String getColorClass() { return colorClass; } public void setColorClass(String colorClass) { this.colorClass = colorClass; }
    }
}
