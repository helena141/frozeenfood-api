package com.elsafrozenfood.wholesale;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface WholesaleOrderRepository extends JpaRepository<WholesaleOrder, Long> {
    List<WholesaleOrder> findByCustomerEmailIgnoreCaseOrderByCreatedAtDesc(String email);
    Optional<WholesaleOrder> findByIdAndCustomerEmailIgnoreCase(Long id, String email);
}
