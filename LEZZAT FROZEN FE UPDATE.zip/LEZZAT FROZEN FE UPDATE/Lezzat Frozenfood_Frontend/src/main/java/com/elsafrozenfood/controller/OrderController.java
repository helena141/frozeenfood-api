package com.elsafrozenfood.controller;

import com.elsafrozenfood.auth.AppUser;
import com.elsafrozenfood.order.CustomerOrder;
import com.elsafrozenfood.order.CustomerOrderRepository;
import com.elsafrozenfood.product.Product;
import com.elsafrozenfood.product.ProductRepository;
import com.elsafrozenfood.repository.AppUserRepository;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller
public class OrderController {
    private final CustomerOrderRepository orders;
    private final ProductRepository products;
    private final AppUserRepository users;
    public OrderController(CustomerOrderRepository orders, ProductRepository products, AppUserRepository users) {
        this.orders=orders; this.products=products; this.users=users;
    }

    @GetMapping("/orders")
    public String myOrders(Authentication auth, Model model) {
        model.addAttribute("orders", orders.findByCustomerEmailIgnoreCaseOrderByCreatedAtDesc(auth.getName()));
        return "orders/list";
    }

    @PostMapping("/orders/create/{productId}")
    public String create(@PathVariable Long productId, @RequestParam(defaultValue="1") Integer quantity,
                         @RequestParam(required=false) String note, Authentication auth, RedirectAttributes redirect) {
        Product product=products.findById(productId).orElse(null);
        if(product==null){redirect.addFlashAttribute("errorMessage","Produk tidak ditemukan."); return "redirect:/products";}
        if(quantity==null || quantity<1 || quantity>100){redirect.addFlashAttribute("errorMessage","Jumlah pesanan harus 1–100."); return "redirect:/products";}
        if(product.getStock()<quantity){redirect.addFlashAttribute("errorMessage","Stok produk tidak mencukupi."); return "redirect:/products";}
        AppUser user=users.findByEmailIgnoreCase(auth.getName()).orElseThrow();
        product.setStock(product.getStock()-quantity); products.save(product);
        orders.save(new CustomerOrder(user.getEmail(),user.getFullName(),product.getId(),product.getName(),quantity,product.getPrice(),cleanNote(note)));
        redirect.addFlashAttribute("successMessage","Pesanan berhasil dibuat. Silakan lakukan pembayaran demo.");
        return "redirect:/orders";
    }

    @PostMapping("/orders/{id}/edit")
    public String edit(@PathVariable Long id, @RequestParam Integer quantity, @RequestParam(required=false) String note,
                       Authentication auth, RedirectAttributes redirect) {
        CustomerOrder order=ownedOrder(id,auth.getName());
        if(order==null){redirect.addFlashAttribute("errorMessage","Pesanan tidak ditemukan.");return "redirect:/orders";}
        if(!"BELUM_DIBAYAR".equals(order.getPaymentStatus())){redirect.addFlashAttribute("errorMessage","Pesanan yang sudah dibayar tidak dapat diedit.");return "redirect:/orders";}
        if(quantity==null || quantity<1 || quantity>100){redirect.addFlashAttribute("errorMessage","Jumlah pesanan harus 1–100.");return "redirect:/orders";}
        Product product=products.findById(order.getProductId()).orElse(null);
        if(product==null){redirect.addFlashAttribute("errorMessage","Produk tidak tersedia.");return "redirect:/orders";}
        int delta=quantity-order.getQuantity();
        if(delta>product.getStock()){redirect.addFlashAttribute("errorMessage","Stok produk tidak mencukupi.");return "redirect:/orders";}
        product.setStock(product.getStock()-delta); products.save(product);
        order.update(quantity,cleanNote(note)); orders.save(order);
        redirect.addFlashAttribute("successMessage","Pesanan berhasil diperbarui."); return "redirect:/orders";
    }

    @PostMapping("/orders/{id}/delete")
    public String delete(@PathVariable Long id, Authentication auth, RedirectAttributes redirect) {
        CustomerOrder order=ownedOrder(id,auth.getName());
        if(order==null){redirect.addFlashAttribute("errorMessage","Pesanan tidak ditemukan.");return "redirect:/orders";}
        if(!"BELUM_DIBAYAR".equals(order.getPaymentStatus())){redirect.addFlashAttribute("errorMessage","Pesanan yang sudah dibayar tidak dapat dihapus.");return "redirect:/orders";}
        products.findById(order.getProductId()).ifPresent(p->{p.setStock(p.getStock()+order.getQuantity());products.save(p);});
        orders.delete(order); redirect.addFlashAttribute("successMessage","Pesanan berhasil dihapus dan stok dikembalikan."); return "redirect:/orders";
    }

    @PostMapping("/orders/{id}/pay")
    public String pay(@PathVariable Long id, Authentication auth, RedirectAttributes redirect) {
        CustomerOrder order=ownedOrder(id,auth.getName());
        if(order==null){redirect.addFlashAttribute("errorMessage","Pesanan tidak ditemukan.");return "redirect:/orders";}
        if(!"BELUM_DIBAYAR".equals(order.getPaymentStatus())){redirect.addFlashAttribute("errorMessage","Pesanan ini sudah dibayar.");return "redirect:/orders";}
        order.setPaymentStatus("LUNAS_DEMO"); order.setOrderStatus("DIPROSES"); orders.save(order);
        redirect.addFlashAttribute("successMessage","Pembayaran demo berhasil. Tidak ada transaksi uang sungguhan."); return "redirect:/orders";
    }

    @GetMapping("/orders/{id}/receipt")
    public void ownReceipt(@PathVariable Long id, Authentication auth, HttpServletResponse response) throws IOException {
        CustomerOrder order=ownedOrder(id,auth.getName());
        if(order==null){response.sendError(404);return;} writeReceipt(order,response);
    }

    @GetMapping("/admin/orders")
    public String adminOrders(Model model) {
        model.addAttribute("orders",orders.findAll(Sort.by(Sort.Direction.DESC,"createdAt")));
        return "admin/orders";
    }
    @GetMapping("/admin/orders/{id}/receipt")
    public void adminReceipt(@PathVariable Long id, HttpServletResponse response) throws IOException {
        CustomerOrder order=orders.findById(id).orElse(null);
        if(order==null){response.sendError(404);return;} writeReceipt(order,response);
    }

    private CustomerOrder ownedOrder(Long id,String email){return orders.findByIdAndCustomerEmailIgnoreCase(id,email).orElse(null);}
    private String cleanNote(String note){if(note==null)return "";String n=note.trim();return n.length()>500?n.substring(0,500):n;}
    private void writeReceipt(CustomerOrder order,HttpServletResponse response)throws IOException{
        response.setCharacterEncoding(StandardCharsets.UTF_8.name()); response.setContentType("text/html; charset=UTF-8");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=nota-pesanan-"+order.getId()+".html");
        String html="<!doctype html><html lang='id'><meta charset='UTF-8'><title>Nota Pesanan LEZZAT</title><body style='font-family:Arial,sans-serif;max-width:700px;margin:40px auto;color:#33281f'><h1>LEZZAT FROZEN FOOD</h1><h2>Nota Pesanan Satuan #"+order.getId()+"</h2><hr><p><b>Pelanggan:</b> "+escape(order.getCustomerName())+"</p><p><b>Email:</b> "+escape(order.getCustomerEmail())+"</p><p><b>Tanggal:</b> "+order.getCreatedAt()+"</p><table style='width:100%;border-collapse:collapse' border='1' cellpadding='10'><tr><th>Produk</th><th>Jumlah</th><th>Harga satuan</th><th>Total</th></tr><tr><td>"+escape(order.getProductName())+"</td><td>"+order.getQuantity()+"</td><td>Rp "+order.getUnitPrice()+"</td><td>Rp "+order.getTotalPrice()+"</td></tr></table><p><b>Status pembayaran:</b> "+escape(order.getPaymentStatus())+"</p><p><b>Status pesanan:</b> "+escape(order.getOrderStatus())+"</p><p><b>Catatan:</b> "+escape(order.getNote()==null?"":order.getNote())+"</p><p>Nota ini merupakan bukti pesanan dari aplikasi LEZZAT.</p></body></html>";
        response.getOutputStream().write(html.getBytes(StandardCharsets.UTF_8));
    }
    private String escape(String value){return value==null?"":value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
}
