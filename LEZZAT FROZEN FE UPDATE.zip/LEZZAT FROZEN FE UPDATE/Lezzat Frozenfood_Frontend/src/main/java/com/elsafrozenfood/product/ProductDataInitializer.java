package com.elsafrozenfood.product;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ProductDataInitializer implements CommandLineRunner {
    private final ProductRepository repository;
    public ProductDataInitializer(ProductRepository repository) { this.repository = repository; }

    @Override public void run(String... args) {
        if (repository.count() > 0) return;
        repository.save(new Product("Nugget Ayam Premium", "Frozen Food", 32000, 25, "🍗", "Favorit keluarga", "product-gold"));
        repository.save(new Product("Sosis Sapi", "Sosis & Olahan", 28000, 30, "🌭", "Praktis dan lezat", "product-pink"));
        repository.save(new Product("Dimsum Ayam", "Dimsum", 35000, 18, "🥟", "Lembut dan gurih", "product-green"));
        repository.save(new Product("Kentang Goreng", "Frozen Food", 24000, 40, "🍟", "Cocok untuk camilan", "product-blue"));
        repository.save(new Product("Bakso Sapi", "Sosis & Olahan", 30000, 20, "🍲", "Kenyal dan nikmat", "product-lilac"));
        repository.save(new Product("Ebi Furai", "Seafood", 39000, 15, "🍤", "Renyah di luar", "product-peach"));
        repository.save(new Product("Fish Roll", "Seafood", 27000, 22, "🐟", "Pilihan seafood", "product-cyan"));
        repository.save(new Product("Chicken Karaage", "Frozen Food", 36000, 17, "🍱", "Mudah disajikan", "product-cream"));
    }
}
